require 'keystone/boot'
require 'keystone/installer'
require 'keystone/compiler'

module Keystone
  VERSION = "0.1.0"
end
